#include <iostream>
#include "Presubmit.hpp"
#include <iostream>
#include "Presubmit.hpp"

int main() {
  return runPreSubmissionChecks() ? EXIT_SUCCESS : EXIT_FAILURE;
}
//
//#include <iostream>

///// preloaded code - don't change it!!!!!
//template<typename T>
//class Vehicle
//{
// protected:
//  std::string _type;
//  T _parkingLocation;
// public:
//  Vehicle(const std::string &type, const T parkingLocation) : _type(type), _parkingLocation(parkingLocation) {}
//  std::string getType() const { return _type; }
//  T getParkingLocation() const { return _parkingLocation; }
//  virtual void print(std::ostream& os) const = 0;
//  virtual Vehicle *copy() const = 0;
//  friend std::ostream &operator<<(std::ostream &os, const Vehicle &vehicle) { vehicle.print(os); return os; }
//  virtual ~Vehicle()=default;
//};
//
//template<typename T>
//class Motorcycle : public Vehicle<T>
//{
// private:
//  std::string _brand;
// public:
//  explicit Motorcycle(const std::string &brand, const T parkingLocation) : Vehicle<T>("Motorcycle", parkingLocation), _brand(brand) {}
//
//  void print(std::ostream& os) const override
//  {
//    os << "Motorcycle: brand: " <<
//       _brand << " , location: " << this->_parkingLocation << ".";
//  }
//
//  Vehicle<T> *copy() const override
//  {
//    auto motorcycle = new Motorcycle(_brand, this->_parkingLocation);
//    return motorcycle;
//  }
//};
//
//
//template<typename T>
//class Jeep : public Vehicle<T>
//{
// private:
//  size_t _power;
// public:
//  explicit Jeep(const size_t power, const T parkingLocation) : Vehicle<T>("Jeep", parkingLocation), _power(power) {}
//
//  void print(std::ostream& os) const override
//  {
//    os << "Jeep: power: " <<
//       _power << " , location: " << this->_parkingLocation << ".";
//  }
//
//  Vehicle<T> *copy() const override
//  {
//    auto jeep = new Jeep(_power, this->_parkingLocation);
//    return jeep;
//  }
//};
//
//
//template<typename T>
//class MazdaCar : public Vehicle<T>
//{
// private:
//  size_t _yearOfManufacture;
// public:
//  explicit MazdaCar(const size_t year, const T parkingLocation) : Vehicle<T>("PrivateCar", parkingLocation), _yearOfManufacture(year) {}
//
//  void print(std::ostream& os) const override
//  {
//    os << "Jeep: year of manufacture: " <<
//       _yearOfManufacture << " , location: " << this->_parkingLocation << ".";
//  }
//
//  Vehicle<T> *copy() const override
//  {
//    auto mazdaCar = new MazdaCar(_yearOfManufacture, this->_parkingLocation);
//    return mazdaCar;
//  }
//};


/************************************************************************/
/******************* implement the Garage class below *******************/
/************************************************************************/
// - Default constructor - zero initialization, initial capacity for array.
// - operator<< for printing.
// - size_t getSize() - return the current size (number of vehicles in the garage) of the garage.
// - size_t getCapacity() - return the current capacity of the garage (places for vehicles - not number of actual vehicles in the garage)
// - Vehicle<T> *getVehicle(size_t ind) - return the vehicle in the corresponding index. Throws an exception in case of invalid input.
// - void insert(const Vehicle<T> *vehicle) - inserts a copy of the given vehicle at the end of the vehicle array.
//template<typename T,size_t CAPACITY =16UL>
//class Garage:
//{
//
//  size_t  capacity;
//  size_t  size;
//  Vehicle<T> *v;
//
// public:
//  Garage(){
//    capacity=16;
//    size =0;
//    v= new Vehicle<T>[16];
//  }
//  size_t getSize(){
//    return size;
//  }
//  size_t getCapacity(){
//    return capacity;
//  }
//  friend std::ostream &operator<<(std::ostream &os,const Garage &g){
//    for(const auto &i :g){
//      os<<i<<std::endl;
//    }
//    return os;
//  }
//  Vehicle<T> *getVehicle(size_t ind){
//    if (ind<0 || ind >capacity || !v[ind]){
//      throw std::invalid_argument("not legal pointer");
//    }
//    else return v[ind];
//
//  }
//  void insert(const Vehicle<T> *vehicle){
//    if (size==capacity){
//      capacity=capacity*2;
//      Vehicle<T> n= new Vehicle<T>[capacity];
//      for (size_t i=0;i<capacity/2;i++){
//        n[i]=v[i].copy();
//      }
//      delete [] v;
//      v=n;
//
//    }
//    v[capacity-1]=vehicle->copy();
//    size++;
//  }
//
//
//
//};
//int main()
//{
//  Motorcycle<int> *motorcycle = new Motorcycle<int> ("Toyota", 1);
//  Jeep<int> *jeep = new Jeep<int> (2000, 2);
//
//  MazdaCar<int> *mazdaCar = new MazdaCar<int> (2020, 3);
//
//  Garage<int> vehiclesContainer;
//  vehiclesContainer.insert (motorcycle);
//  vehiclesContainer.insert (jeep);
//  vehiclesContainer.insert (mazdaCar);
//
//  std::cout << vehiclesContainer;
//}