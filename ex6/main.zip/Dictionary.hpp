//#include "HashMap.hpp"
#define INVALID "invalid_argument pleease do something "
class InvalidKey : public std::invalid_argument {
 public:
  explicit InvalidKey(const std::string &st): std::invalid_argument (st){}
};
 class Dictionary:public HashMap<std::string,std::string > {
  public:
   bool erase(const std::string key_t) override{
     if(HashMap::erase(key_t)){
       return true;
     }
     throw InvalidKey(INVALID);
   }
   template<class FowardIr>
   void update(const FowardIr &begin,const FowardIr &end ){
     for(auto i=begin;i!=end;++i){
       this->operator[] (i->first)=i->second;
     }

   }


 };