#include <stdexcept>
#include <vector>
template <class KeyT,class ValueT >
class HashMap{
 protected:
  typedef std::vector<std::pair<KeyT,ValueT>> my_map;
  my_map *_data;
  int  _size;
  int _capacity;
//  bool _empty=true;
 public:
  int hash_function(const KeyT key)const{
      return std::hash<KeyT>() (key) &(_capacity-1);
  }
  virtual ~HashMap(){
    delete [] _data;
  }
  HashMap():_size(0),_capacity(16){
    _data=new my_map [16];
    if (!_data){
      throw std::domain_error("error1");
    }
  }
  HashMap(const HashMap &hash_map):HashMap()
        {
    if (!hash_map._data){
      throw std::domain_error("error in Hashmap constactor");
    }
    _capacity=hash_map._capacity;
//    delete[] _data;
//    _data=new my_map[_capacity];
//    _size=hash_map._size;
    clear();
    for (size_t i=0;i<_capacity;i++){
      for (auto pair: hash_map._data[i]){
//      _data[hash_function (pair.first)].push_back
//      (std::make_pair (pair.first,pair.second));
        insert (pair.first,pair.second);
      }
    }

  }
  HashMap(const std::vector<KeyT> keys,const std::vector<ValueT> value):_size
  (0),_capacity
      (16){
    if (keys.size() != value.size()){
      throw std::domain_error("er in ");
    }
    _data=new my_map[16];
    _size=keys.size();
    int e=0;
    int y=0;
    for (size_t i=0;i<keys.size();i++){

      if (!contains_key (keys[i])){
        y++;
        _data[hash_function (keys[i])].push_back(std::make_pair(keys[i],value[i]));

      }
      else {
        erase (keys[i]);
        _data[hash_function (keys[i])].push_back(std::make_pair(keys[i],value[i]));
        e++;

      }
//      _data[hash_function (keys[i],-1)]=value[i];
    }
    _size=y-e;
    if (get_load_factor()<0.25){
      dicrease();
    }
    if (get_load_factor()>0.75){
      increase();
    }
  }
  int size() const {
    return _size;
  }
  int capacity()const {
    return _capacity;
  }
  bool empty() const {
    return _size==0;
  }
  bool insert(const KeyT keys,const ValueT &value_t){
    if (!contains_key (keys)){

      //TODO change the size and the capacty
      auto z=hash_function (keys);
      this->_data[z].push_back(std::make_pair (keys,
                                                                 value_t));
      ++_size;
      if (get_load_factor() > 0.75){
        increase();
      }

      return true;
    }
    else {
      return false;
    }

  }
  bool contains_key(const KeyT keys)const{
    bool v= check_in_data (keys);
    return v;

  }
//  HashMap operator() (){
//    return;
//  }
  int check_in_data(const KeyT keys)const
{
    int cur =0;
    for (const  auto p :_data[hash_function (keys)]){
        if (p.first==keys){
          return true;
        }
      }

    return false;
}

  ValueT operator [](const KeyT key_t) const {
    for (const auto pair:_data[hash_function (key_t)])
    {
      if (pair.first == key_t)
      {
        return pair.second;
      }
    }
    return ValueT();
  }

  ValueT &operator [](const KeyT &key_t){
    insert (key_t,ValueT());
    for (auto &pair:_data[hash_function (key_t)])
    {
      if (pair.first == key_t)
      {
        return pair.second;
      }
    }
//    return ValueT();
  }
  ValueT at(const KeyT &keys)const {
    if(!contains_key (keys)){
      throw std::domain_error ("problem at at const ");

    }
    return (*this)[keys];

  }
  ValueT &at(const KeyT keys){
  if (contains_key (keys))
  {
    for ( auto &pair:_data[hash_function (keys)])
    {
      if (pair.first == keys)
      {
        return pair.second;
      }

//    return (*this)[keys];
  }
  }
  throw std::domain_error ("problem at at");
  }
  virtual bool erase(const KeyT key_t){
    if(!contains_key (key_t)){
      return false;
    }
    else {
      int i=0;
      for (auto &cur:_data[hash_function (key_t)]){
        if (cur.first==key_t){
          _data[hash_function (key_t)].erase(_data[hash_function (key_t)]
                                                    .begin()+i);
          --_size;
//          dicrease();
          if(get_load_factor()<0.25){
            dicrease();
          }
//          (get_load_factor()<0.25 ?increase():NULL);
          return true ;
        }
        else {
          i++;
        }
      }

    }
    return false;
  }

  double get_load_factor(){
    return (double )_size/(double )_capacity;
  }
  int bucket_index(const KeyT &keys)  {
    if (contains_key (keys)){
      for (size_t i=0;i<_capacity;i++){
        for (auto &pair:_data[i]){
          if (pair.first==keys)
          {
            return (int) i;
          }
          else
          {
          }
        }
      }
    }
    else{
      throw std::invalid_argument ("aqwxcvbn,kloiuytredfgh");
    }
    return 0;
  }
  int bucket_size(const KeyT &keys){
    if (contains_key (keys)){
     return  _data[hash_function(keys)].size();
  }
    else{
      throw std::invalid_argument ("azertyui");
    }
    return 0;
  }
  void clear(){
    delete[] _data;
    _data =new my_map [16];
    _size=0;
  }
  class Iterator{
    friend class HashMap;
   private:
    const HashMap<KeyT,ValueT> *_hash_map;
    size_t _cur_buk;
    size_t _cur_ind;

   public:
    typedef const std::pair<KeyT,ValueT> pair_1;
    typedef  const pair_1 &reference;
    typedef  const pair_1 *pointer;
    typedef int diferent_type;
    typedef   std::forward_iterator_tag forward_iterator;
   private:
    Iterator(const HashMap<KeyT,ValueT> *hash_map_1,size_t cur_buk,size_t
    cur_ind):
    _hash_map(hash_map_1),_cur_buk(cur_buk),_cur_ind(cur_ind){}
   public:
    reference operator*()const {
      return _hash_map->_data[_cur_buk][_cur_ind];
    }
    pointer operator->()const{
      return &(operator*());
    }
    bool operator ==(const Iterator &iterator)const {
      return (_cur_ind==iterator._cur_ind && _cur_buk==iterator._cur_buk &&
      _hash_map==iterator._hash_map);
    }
    bool operator !=(const Iterator &iterator)const {
      return !operator== (iterator);
    }
    Iterator& operator++() {
      auto  map_1=_hash_map->_data[_cur_buk];
      if (_cur_ind==map_1.size()-1){
        _cur_buk++;
        _cur_ind=0;
        for (int i = _cur_buk; i < _hash_map->capacity() ; ++i)
        {
          if (!_hash_map->_data[i].empty ())
          {
            _cur_buk = i;
            return *this;
          }
        }
        _cur_buk=_hash_map->capacity();
        return *this;
        //TODO

      }

        ++_cur_ind;
        return *this;
    }
    Iterator operator++(int)const{
      Iterator it(*this);
      this->operator++();
      return it;
    }





  };
  typedef Iterator iterator;
  iterator cbegin()const {
    for (int i=0;i<_capacity;i++){
      if(_data[i].empty()){ }
      else{
        return Iterator(this,i,0);
      }
    }
    return Iterator (this,0,0);
  }
  iterator cend()const {
    return Iterator(this,_capacity,0);

  }
  iterator begin()const{
    return cbegin();
  }
  iterator end()const {
    return cend();
  }
  HashMap &operator=(const HashMap hash_map){
    if (*this==hash_map){
      return *this;
    }
    _capacity=hash_map.capacity();
    _size=hash_map.size();
    delete []_data;
    _data=new my_map[_capacity];
    for (size_t i=0;i<_capacity;i++){
      insert (hash_map._data[i].first,hash_map._data[i].second);
    }
    return *this ;

  }
  bool operator ==(const HashMap &hash_map)const {
    if (_capacity!=hash_map.capacity() ||_size!=hash_map._size){
      return false;
    }
    for(size_t i=0;i<_capacity;i++){
      for ( const auto pair:_data[i]){
        if (contains_key (pair.first) && hash_map[pair.first] != pair.second){
          return false;
        }
      }
    }
    return true;
  }
  bool operator !=(const HashMap &hash_map)const{
    return !(this->operator== (hash_map));
  }
  void increase(){
    int n_c=_capacity*2;
    _capacity=n_c;
    my_map *map;
    map=new my_map[n_c];
    for (size_t i=0;i<_capacity/2;++i){
      for(const auto &pair:_data[i]){
        map[hash_function (pair.first)].push_back (std::make_pair (pair
        .first,pair
        .second));
      }
    }
    delete[]_data;
    _data=map;
  }
  void dicrease(){
    int n_c=_capacity/2;
    _capacity=n_c;
    my_map *map;
    map=new my_map[n_c];
    for (size_t i=0;i<_capacity*2;++i){
      for(const auto pair:_data[i]){
        map[hash_function (pair.first)].push_back
        (std::make_pair
        (pair    .first,pair
                                                                        .second));
      }
    }
    delete[]_data;
    _data=map;
  }



};